#sum of two bits can be obtained by performing XOR(^) of the two bits.
#Carry bit can be obtained by performing AND(&) of two bits
#and is a logical AND that returns True if both  operands are True whereas '&' is a bitwise operator in python
#that acts on bits and performs bit by bit operation
#print('10&5 {}'.format(10&5))
#print('5&10 {}'.format(5&10))
#print('5&5 {}'.format(5&5))
#print('0&0 {}'.format(0&0))
def add(x,y):
    while (y!=0):# iterate till there is no carry
        # carry now contains common
        #set bits of x and y
        carry = x & y
        print("carry {}".format(carry))
        # sum of bits of x and y where atleast one of the bits is not set
        x = x ^ y
        print("x {}".format(x))
        # carry is shifted by one so that
        # adding it to x gives the required sum
        y = carry << 1
        print("y {}".format(y))
    return x
print("x + y is",add(15,32))
#print("x + y is",add(32,32))
#print(10>>0)
#print(10<<0)
def subtract(x, y):
    # Iterate till there
    # is no carry
    while (y != 0):
        # borrow contains common
        # set bits of y and unset
        # bits of x
        #print(x,y)
        borrow = (~x) & y
        #print(~x)
        #print("borrow {}".format(borrow))
        # Subtraction of bits of x
        # and y where at least one
        # of the bits is not set
        #print(x,y)
        x = x ^ y
        #print("x {}".format(x))
        # Borrow is shifted by one
        # so that subtracting it from
        # x gives the required sum
        y = borrow << 1
        #print("y {}".format(y))
    return x


# Driver Code
x = -29
y = 13
#print("x - y is", subtract(x, y))

















