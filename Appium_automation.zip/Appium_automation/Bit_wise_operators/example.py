class Employee(object):
    def __init__(self,name,id):
        self.name = name
        self.id = id

    def display(self):
        print("Name: {} ID: {} ".format(self.name,self.id))

class Manager(Employee):

    def __init__(self,name,id,salary):
        self.salary = salary
        Employee.__init__(self,name,id)

    def set_salary(self):
        self.salary = salary

    def get_salary(self):
        print("salary: {}".format(self.salary))

    def display(self):
        return ("Name: {}, ID: {} , Salary: {}".format(self.name,self.id,self.salary))

mg = Manager("chenna", 4001, "10L")
em = Employee("kesava", 5001)
#em.display()
print(mg.display())
