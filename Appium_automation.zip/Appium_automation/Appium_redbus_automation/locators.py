

class Locator(object):


    side_menu = '//*[@id="root"]/div[1]/div/div/div[1]/div'

    sign_in_up = "/html/body/div[3]/div/div/ul/li[1]/a/span[2]"
    sign_page = '/html/body/div[6]/div/div[2]/div/h4'

    search_Buses = "/html/body/div[3]/div/div/ul/li[2]/a/span[2]"
    Buses_page = '//*[@id="root"]/div[3]/div[3]/button'

    Offers = "/html/body/div[3]/div/div/ul/li[3]/a/span[2]"
    offers_page = '//*[@id="root2"]/div/div[1]/span[2]'

    Refer_and_Earn = "/html/body/div[3]/div/div/ul/li[4]/a/span[2]"
    refer_page = '/html/body/div[6]/div/div[2]/div/h4'

    Help = "/html/body/div[3]/div/div/ul/li[5]/a/span[2]"
    help_page = '//*[@id="reactContentMount"]/div/div/div/div[2]'

    Get_Ticket_Details = "/html/body/div[3]/div/div/ul/li[6]/a/span[2]"
    ticket_page = '//*[@id="root"]/div[2]/form/h3'

    About_Us = "/html/body/div[3]/div/div/ul/li[7]/a/span[2]"
    about_us_page = '//*[@id="root2"]/div/div[1]/span[2]'

    Cancel_Ticket = "/html/body/div[3]/div/div/ul/li[8]/a/span[2]"
    cancel_page = '//*[@id="root"]/div[1]/span[2]'

    Reschedule_Ticket = "/html/body/div[3]/div/div/ul/li[9]/a/span[2]"
    reschedule_page = '//*[@id="root"]/div[1]/span[2]'

    Settings = "/html/body/div[3]/div/div/ul/li[10]/a/span[2]"
    settings_page = '//*[@id="root2"]/div/div[1]/span[2]'