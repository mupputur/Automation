from Q2 import *


import unittest


class TestQ2(unittest.TestCase):

    def test1(self):
        """
        Test with different input size
        """
        parsms = ["popupx", "popup"]
        resp = is_anagram1(parsms[0], parsms[1])
        self.assertFalse(resp, "Failed function is_anagram1 with {}".format(parsms))


    def test2(self):
        """
        Test with valid data set
        """
        parsms = ["popup", "uppop"]
        resp = is_anagram1(parsms[0], parsms[1])
        self.assertTrue(resp, "Failed function is_anagram1 with {}".format(parsms))
    
    def test3(self):
        """
        Test with different input size
        """
        parsms = ["popup", "manoh"]
        resp = is_anagram1(parsms[0], parsms[1])
        self.assertFalse(resp, "Failed function is_anagram1 with {}".format(parsms))

    def test4(self):
        """
        Test with valid data set
        """
        parsms = ["popup123", "321uppop"]
        resp = is_anagram1(parsms[0], parsms[1])
        self.assertTrue(resp, "Failed function is_anagram1 with {}".format(parsms))
unittest.main()

        


