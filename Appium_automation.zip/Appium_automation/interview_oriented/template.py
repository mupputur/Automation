#from Q2 import *


import unittest


class TestQ1(unittest.TestCase):

    def test1(self):
        """
        Test with different input size
        """
        params = []
        self.assertFalse()


    def test2(self):
        """
        Test with valid data set
        """
        self.assertTrue()
    
    def test3(self):
        params = []
        self.assertFalse()

    def test4(self):
        params = []
        self.assertTrue()
unittest.main()

        


