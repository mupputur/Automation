#7Check given string is a palindrome or not?


def is_palindrome(str):
    for i in range(1,len(str)):
        if str[i] != str[-i-1]:
            res = False
            break
        else:
            res = True
    return res
    
#n_str = input("Enter string:")
#print(is_palindrome(n_str))
