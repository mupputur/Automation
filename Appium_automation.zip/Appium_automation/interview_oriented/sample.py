from selenium.webdriver.common.keys import Keys
from selenium import webdriver


driver = webdriver.Chrome(executable_path="C:\\Users\\lenova\\Downloads\\chromedriver88\\chromedriver.exe")
driver.implicitly_wait(30)

driver.get('https://www.naukri.com/mnjuser/homepage')

driver.find_element_by_id('usernameField').send_keys('chennakesava.davala@gmail.com')
driver.find_element_by_id('passwordField').send_keys('7032798375')
driver.find_element_by_xpath('//*[@id="loginForm"]/div[2]/div[3]/div/button[1]').click()

driver.find_element_by_xpath('//*[@id="root"]/div/div/span/div/div/div/div[2]/div/div[2]/div[1]/div/div[1]/div[2]/div').click()
driver.find_element_by_xpath('//*[@id="lazyAttachCV"]/div/div/div[2]/div[1]/div[1]/div[2]/div/i').click()
ele = driver.find_element_by_tag_name('html')
ele.send_keys(Keys.END)
driver.save_screenshot("file.png")
driver.close()