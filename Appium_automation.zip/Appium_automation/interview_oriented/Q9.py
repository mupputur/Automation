"""
def search_element(element,list_x):
    for ele in list_x:
        if str(ele) == element:
            return True

list_x=[1,'ab',34,'@','xyz']
input_ele = input("enter element to search:")
print(search_element(input_ele,list_x))
"""
x="python"
c = ""
for i in x:
    c=c+i+"-"
    print(c)

