#4Reverse a string using recursion?
'''
def rec_str(new_str):
    rev_string=""
    if len(new_str)> 0:
        i = len(new_str)-1
        if i >= 0:
            h=new_str[:i]
            rev_string = rev_string+new_str[i]+rec_str(h)
    return rev_string

#new_str =input("Enter String for reverse recursion:")
#print(rec_str(new_str))
'''
#reverse a string

def reverse_str(input):
    output = ''
    for i in input:
        output = i + output

    return output

print(reverse_str('hyderabad'))
