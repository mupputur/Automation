#6Reverse a words in given sentence?


def rev_word_sent(s):
    l = s.split()
    a = []
    if len(l)>1:
        for i in l:
            p = i[::-1]
            a.append(p)
        j = " ".join(str(e) for e in a)
        return j
    else:
        return False

s = input("Enter sentence to reverse:")
print(rev_word_sent(s))
