"""
Q1)Duplicate char from a string?
Input1:helloworld	Output1:[‘l’, ’o’]
Input2:programming	Output2:[‘r’, ’m’, ’g’]

"""
# Version1
def get_dup_chars(str_input):
    dups = []
    non_dups = []
    for ch in str_input:
        if ch not in non_dups:
            non_dups.append(ch)
        else:
            if ch not in dups:
                dups.append(ch)
    return dups
            

resp = get_dup_chars("helloworld")
print(resp)

# Version2
"""
def get_dup_chars2(str_input):
    d= {}
    for ch in str_input:
        if ch not in d:
            d[ch] = 1
        else:
            d[ch] = d[ch] +1
    return [k for k in d if d[k]>1] # List comprehension 
            

resp = get_dup_chars("helloworld")
print(resp)
"""
