from Q5 import *


import unittest


class TestQ5(unittest.TestCase):

    def test1(self):
        """
        Test with different input size
        """
        params = "ABCQW"
        resp = is_str_contains_digit(params)
        self.assertFalse(resp,"string not contains digits".format(params))

    def test2(self):
        """
        Test with valid data set
        """
        params = "AB2HJ76F"
        resp = is_str_contains_digit(params)
        self.assertTrue(resp,"string contains digits".format(params))

  
    def test3(self):
        """
        Test with all data of digits
        """
        params = "12345"
        resp = is_str_contains_digit(params)
        self.assertTrue(resp,"string contains digits".format(params))

unittest.main()

        


