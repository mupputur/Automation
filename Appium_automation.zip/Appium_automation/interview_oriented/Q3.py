#3Find first non-repetition char from string?
"""
Q3)Find first non-repetition char from string?
Input1:pythonprogram      Output1: y
Input2:grammering	  Output2: a

"""
def non_rep_str(x):
    d = {}
    c = 0
    t = ""
    for i in x:
        if i not in d:
            d[i]=c
        else:
            c=c+1
            d[i]=c
    for k,v in d.items():
        if d[k] == 0:
            return k
#x = input("Enter string:")    
print(non_rep_str("pytthhonnpyrogram"))    

    
    
        

        
