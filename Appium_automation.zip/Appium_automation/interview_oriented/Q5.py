#5How do check strings contains only digits?


def is_str_contains_digit(s):
    for i in s:
        if i in "1234567890":
            res = True
            break
    else:
        res = False
    return res

s = input("Enter String and find is it contains digits:")
print(is_str_contains_digit(s))
