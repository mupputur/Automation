#2Check two string are anagrams are not?
"""
Q2)Check two string are anagrams are not?
Input1:mmmmp,uppop	Output1:True
Input2:try,tri		Output2:False

"""
def is_anagram1(str1, str2):
    x = set(str1)
    y = set(str2)
    if len(x-y) == 0 and len(y-x) == 0:
        return True
    else:
        return False

def is_anagram2(str1, str2):
    if len(str1) != len(str2):
        return False
    for i in range(0, len(str1)):
        if str1[i] not in str2 and str2[i] not in str1:
            return False
    else:
        return True
        


