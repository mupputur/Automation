"""
# integers in string get integers as output
def str_int(str):
    output = ""
    for i in str:
        if ord(i)==48:
            output  = output + i
    return output

str = '000b000a000n000g000l000o000r000e000'
print(str_int(str))

# count of integers in string get integers as output
def count_str_int(str):
    count = 0
    for i in str:
        if ord(i)==48:
            count  = count + 1
    return count

str = '000b000a000n000g000l000o000r000e000'
print(count_str_int(str))


#Python Program to Print Right Angled Triangle Star Pattern

def right_triangle():
    for i in range(1, rows + 1):
        for j in range(1, i + 1):
            print('*', end=' ')
        print()

rows = int(input("Enter total number of rows: "))
right_triangle()

"""
#input = [1,100,5,99,50,1000,10000]
#output = {'1': ['1', '5'], '3': ['100'], '2': ['99', '50'], '4': ['1000'], '5': ['10000']}

def list_dict():
	lst_str = []
	d = dict()
	for x in lst_new:
		lst_str.append(str(x))
	#print(lst_str)
	for x in lst_str:
		key = str(len(x))
		if key not  in d.keys():
			d.update({key:[x]})
		else:
			d[key].append(x)
	return d,lst_str
lst_new = [1,100,5,99,50,1000,10000]
print("dict values of d {}".format(list_dict()))

# string values into dictionary key and value
def func():
    d = {}
    for i in v:
        if i not in d:
            d[i]=1
        else:
            d[i]=d[i]+1
    return d
v="aaaabbbcccccddeeee"
print(func())


v="aaaabbbcccccddeeeeaaab"
counter =1
d=""
for i in range(len(v)):
	if i!=len(v)-1 :
		if v[i] == v[i+1] :
			counter+=1
	else:
		d=d+str(counter)
		counter=1
print(d)


#Print Even numbers in a list using Lambda function
my_list = [3,5,2,11,6,8]
list_Even_Numbers = list(filter(lambda varX: varX % 2 == 0,my_list))
print("Following are Even numbers in the list {}".format(list_Even_Numbers))


#Print Odd numbers in a list using Lambda function
my_list = [3,5,2,11,6,8]
list_Odd_Numbers = list(filter(lambda varX: varX % 2 == 1,my_list))
print("Following are Odd numbers in the list {}".format(list_Odd_Numbers))

#list with normal way
fruits = ["apple", "banana", "cherry", "kiwi", "mango"]
newlist = []

for x in fruits:
  if "a" in x:
    newlist.append(x)

print(newlist)

#list with list comprehension
#syntax   [newlist = [expression for item in iterable if condition == True]]
fruits = ["apple", "banana", "cherry", "kiwi", "mango"]

newlist = [x for x in fruits if "a" in x]

print(newlist)
#two lists combinely into dictnoary
def list_to_dict():
	d = dict(zip(a, b))
	return d
a = ['a', 'b', 'c', 'd']
b = [1, 2, 3, 4]
print(list_to_dict())

#duplicate elements and duplicate count
x = [1,2,5,3,4,1,5,3,4]
y=[]
z=[]
counter = 0
for i in x:
	if i not in y:
		y.append(i)
	else:
		z.append(i)
		counter = counter+1
print(counter)
print(z)

#3X3 matrix form

row = int(input("Enter a number of rows : "))
column = int(input("Enter a number of column : "))

matrix = []

for i in range(row):
    a = []
    for j in range(column):
        a.append(int(input("enter values : ")))
    matrix.append(a)

print(matrix)

# Reverse a list
x = [10,20,30,40,50,60,70]
for i in range(len(x)//2):
    #print(i)
    x[i],x[len(x)-i-1]=x[len(x)-i-1],x[i]
#print(x[len(x)-i-1])
print(x)

# Python3 code to demonstrate working of
# Duplicate element indices in list
# Using enumerate + loop

# initializing list
test_list = [1, 4, 5, 5, 5, 9, 1,5,9,1,4,2,3,4]
m=[]
res=[]
for i,value in enumerate(test_list):
    #print("i {}".format(i))
    #print("value {}".format(value))
    if value not in m:
        m.append(value)
    else:
        res.append(i)
print("indices of duplicate values = {} ".format(res))
print("duplicate values = {}".format(m))



"""
# printing original list
print("The original list is : " + str(test_list))
print(type(str(test_list)))

# Duplicate element indices in list
# Using set() + loop
oc_set = set()
print(type(oc_set))
res = []
for idx, val in enumerate(test_list):
    if val not in oc_set:
        oc_set.add(val)
    else:
        res.append(idx)

    # printing result
print("The list of duplicate elements is :  " + str(res))
"""
"""
def func(x_list,del_str):
    output=""
    for i in range(0,len(x_list)-1):
        #print(i)
        output = output+x_list[i]+del_str
    #print(output)
    output=output+x_list[-1]
    print(output)
x_list = ['a','n','e','m']
func(x_list,del_str='-')
"""
"""
#reverse each element in a list and reverse entire list
a = ['hyderabad','bangalore','ongole']
list = []
print(a[::-1])
for i in a[::-1]:
    print(i[::-1])
    list.append(i[::-1])
print(list)
"""