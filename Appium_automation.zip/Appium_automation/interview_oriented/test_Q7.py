#from Q2 import *


import unittest


class TestQ7(unittest.TestCase):

    def test1(self):
        """
        Test with different input size
        """
        params = "1234321"
        self.assertTrue()


    def test2(self):
        """
        Test with valid data set
        """
        self.assertTrue()
    
    def test3(self):
        params = []
        self.assertFalse()

    def test4(self):
        params = []
        self.assertTrue()
unittest.main()

        


