'''
what is list
    list is mutable data type which we can change or modify the elements
what are list functions
    list functions are append,pop,remove,insert,extend,sort
what is the difference between append and insert
    append function add the element at the end of the list while insert function will be inserted on the index bases
can tuple can be add by using append function for the list
    yes we can add tuple by using append function
how is memory managed in python
    memory managed in python is managed by python private heap space
    all python objects and data  structures are located in a private heap
    the python interpreter takes care of this
what is dictnary in python
    it defines one-to-one relationship between keys and values
    it contains pair of keys and thier corresponding values
what is module
    a set of related functions combined as single unit are known as module
    example os,json etc or simply we can say its a library , in python in general all .py file will act as a module
what is lambda function
    lambda function is a anonymous function and it can be used to define a funtion without name
    when the function logic is implememted with simple exprerssion

    The lambda function mostly we use with map and filter functions

    lambda argument: expression
how to open a file
    By using open() function we can open a function by passing the filepath and mode as parameters
    #with open(path+file_name.txt,'r/w') as f
what is the difference between write mode and append mode
    When we open a  existing file using write mode the file will be overridden. Where as if we open a file using append
    mode the data will be added the end of the file.

    When we open a existing file using write mode the previous data will be overridden with new data.
what is iterator in python
    an iterator is an object that  can be iterated upon
    that means you can traverse through all the values
what is generator in python
    a functions that returns an iterable set of items are called generator
    yeild is a keyword to define generator

'''
# minimum number from a given list
def func(list):
    num = list[0]
    for i in list:
        if i<num:
            num = i
    return num
list = [5,6,8,3,9,4]
print(func(list))

# given list to make power of 4 with  comprehensive
def func(old_list):
    new_list = [i ** 4 for i in old_list]
    return new_list
old_list = [1,2,3,4]
print(func(old_list))
'''
# given list to make power of 4
def func(old_list):
    new_list =[]
    for i in old_list:
        new_list.append(i**4)
    :return new_list
old_list = [1,2,3,4]
print(func(old_list))
'''
'''
def func():
    for i in range(10):
        print(i)
        if i==5:
            break
func()

'''
def square(n):
    return n*n

def is_even(n):
    if n % 2 == 0:
        return True


# WAP find sqaure each number from the given list

x = [2, 4, 6, 8]
print("Map Input: ", x)
y = [(map(square, x))]
print("Map Output: ", y)

# WAP find all even number from the given list
x2 = [2, 3, 4, 5, 6, 8, 12, 13, 15, 16, 17]
print("Input: ", x2)
y2 = [(filter(is_even, x2))]
print("Output: ", y2)


