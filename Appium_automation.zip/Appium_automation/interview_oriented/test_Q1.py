from Q1 import *


import unittest


class TestQ1(unittest.TestCase):

    def test1(self):
        """
        Test with different input by appliying dot inbetween
        """
        params = ["google.com"]
        resp = get_dup_chars(params[0])
        self.assertEqual(resp,['o', 'g'])
    def test2(self):
        """
        Test with valid input
        """
        params = ["programming"]
        resp = get_dup_chars(params[0])
        self.assertEqual(resp,['r', 'm', 'g'])
    def test3(self):
        """
        Test with no duplicate characters
        """
        params = ["python"]
        resp = get_dup_chars(params[0])
        self.assertEqual(resp,[])

unittest.main()

        


