from Q3 import *


import unittest


class TestQ3(unittest.TestCase):

    def test1(self):
        """
        Test with different input size
        """
        parsms = []
        self.assertFalse()


    def test2(self):
        """
        Test with valid data set
        """
        self.assertTrue()
    
    def test3(self):
        parsms = []
        self.assertFalse()

    def test4(self):
        parsms = []
        self.assertTrue()
unittest.main()

        


