from Q4 import *


import unittest


class TestQ4(unittest.TestCase):

    def test1(self):
        """
        Test with invalid input 
        """
        params = "nohtyp"
        resp = rec_str(params)
        self.assertEqual(resp, "python")

    def test2(self):
        """
        Test with valid data set
        """
        params = "Gaming"
        resp = rec_str(params)
        self.assertEqual(resp, "gnimaG")

    def test3(self):
        """
        Test with different data 
        """
        params = "_1_2_3_4"
        resp = rec_str(params)
        self.assertEqual(resp, "4_3_2_1_")

unittest.main()

        


