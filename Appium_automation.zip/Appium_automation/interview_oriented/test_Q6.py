from Q6 import *


import unittest


class TestQ6(unittest.TestCase):

    def test1(self):
        """
        Test with different input size
        """
        params = "python is robust"
        resp = rev_word_sent(params)
        self.assertTrue(resp,"reverse string successfully".format(params))


    def test2(self):
        """
        Test with valid data set
        """
        params = "python"
        resp = rev_word_sent(params)
        self.assertFalse(resp,"Failed to reverse string ".format(params))
    
    def test3(self):
        params = "123 456 789"
        resp = rev_word_sent(params)
        self.assertTrue(resp,"reverse string successfully".format(params))

    def test4(self):
        params = "123"
        resp = rev_word_sent(params)
        self.assertFalse(resp,"Failed to reverse string ".format(params))
unittest.main()

        


