from selenium import webdriver

driver = webdriver.Chrome(executable_path="C:\\Users\\lenova\\Downloads\\chromedriver88\\chromedriver.exe")
driver.implicitly_wait(10)
driver.get("https://accounts.google.com/ServiceLogin/signinchooser?service=mail&passive=true&rm=false&continue=https%3A%2F%2Fmail.google.com%2Fmail%2F%3Ftab%3"
           "Drm%26ogbl&scc=1&ltmpl=default&ltmplcache=2&emr=1&osid=1&flowName=GlifWebSignIn&flowEntry=ServiceLogin")

driver.find_element_by_xpath("//div[@class='w1I7fb']").click()
driver.find_element_by_xpath("//input[@class='whsOnd zHQkBf'][1]").send_keys("7032798375")
driver.find_element_by_xpath('//div[@class="VfPpkd-RLmnJb"][1]').click()
driver.close()

def func(n):
     for i in range(0,n):
         for j in  range(0,i+1):
             print("*",end="")
    print("")
n = int(input("enter a number of rows : "))
func(n)