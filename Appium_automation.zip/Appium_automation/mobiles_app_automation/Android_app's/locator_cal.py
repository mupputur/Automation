import time
from selenium import webdriver

class Redbus:

    def func(self):
        self.driver = webdriver.Chrome(executable_path="C:\\Users\\lenova\\Downloads\\chromedriver88\\chromedriver.exe")
        self.driver.get("https://www.redbus.in/")
        time.sleep(10)
        self.driver.find_element_by_xpath("//*[@id='src']").send_keys("ongole")
        time.sleep(5)
        self.driver.find_element_by_xpath("//*[@id='search']/div/div[1]/div/ul/li[1]").click()
        time.sleep(3)
        self.driver.find_element_by_xpath("//*[@id='dest']").send_keys("proddutur")
        time.sleep(3)
        self.driver.find_element_by_xpath("//*[@id='search']/div/div[2]/div/label").click()
        time.sleep(3)
        self.driver.find_element_by_xpath("//*[@id='search']/div/div[3]").click()
        time.sleep(3)
        self.driver.find_element_by_xpath("//*[@id='rb-calendar_onward_cal']/table/tbody/tr[6]/td[3]").click()
        time.sleep(3)
        self.driver.find_element_by_xpath('//*[@id="search_btn"]').click()
        """
        time.sleep(3)
        ele=self.driver.find_elements_by_xpath('//*[@id="root"]/div/div[2]/div[2]/div[3]/div/div/div[2]/div')

        for i in ele:
            resp = i.text
            res = resp.split()
            #print(res)
            #list.append(res)
            APSRTC = []
            if 'APSRTC' in res:
                APSRTC.append(res[0])
                APSRTC.append(res[9])
                APSRTC.append(res[10])
                print(APSRTC)
        """
        time.sleep(2)
        self.driver.find_element_by_xpath('//*[@id="root"]/div/div[2]/div[2]/div[3]/div/div/div[2]/div/div[4]/div[2]').click()
        time.sleep(3)
        ele=self.driver.find_elements_by_xpath('//*[@id="15574855"]/div')
        print(type(ele))
        print(len(ele))
        for i in ele:
            print(i.text)
        time.sleep(10)

        self.driver.close()


s = Redbus()
s.func()

