import time
from appium import webdriver

class Connect:

    def __init__(self):
        self.driver = webdriver
        self.connect()
        self.pop_up_handle()

    def connect(self):
        try:
            capabilities = {'platformName': 'Android', 'platformVersion': '10',
                            'deviceName': 'chenna', 'deviceID': '8cc6f1da',
                            'appPackage':'com.miui.calculator','appActivity':'.cal.CalculatorActivity'}

            self.driver = webdriver.Remote('http://localhost:4723/wd/hub', capabilities)
            print("Connection successfully done")
            return self.driver

        except Exception as e:
            print("Error while connecting with appium {}".format(e))

    def pop_up_handle(self,timeout=10):
        try:
            ele = self.driver.find_element_by_id('android:id/button1')
            ele.click()
            #time.sleep(3)
            print("pop-up clicked successfully")
        except Exception as e:
            print("Error with pop-up handling {}".format(e))

    def clear(self,timeout=5):
        try:
            ele = self.driver.find_element_by_accessibility_id('clear')
            ele.click()
            #time.sleep(3)
            print("clear clicked successfully")
        except Exception as e:
            print("Error while clicking clear button {}".format(e))

    def addition(self):
        try:
            ele8 = self.driver.find_element_by_id('com.miui.calculator:id/btn_8_s').click()
            #time.sleep(3)
            ele_plus = self.driver.find_element_by_accessibility_id('plus').click()
            #time.sleep(3)
            ele5 = self.driver.find_element_by_id('com.miui.calculator:id/btn_5_s').click()
            #time.sleep(3)
            ele_equals = self.driver.find_element_by_accessibility_id('equals').click()
            #time.sleep(3)
            result = self.driver.find_element_by_id('com.miui.calculator:id/result')
            print("Addition done successfully")
            return result.text
        except Exception as e:
            print("something went wrong in calculator {}".format(e))

    def subtraction(self,timeout=5):
        try:
            clear = self.clear()
            #clear = self.driver.find_element_by_accessibility_id('clear').click()
            #time.sleep(3)
            ele8 = self.driver.find_element_by_id('com.miui.calculator:id/btn_8_s').click()
            #time.sleep(3)
            ele_plus = self.driver.find_element_by_accessibility_id('minus').click()
            #time.sleep(3)
            ele5 = self.driver.find_element_by_id('com.miui.calculator:id/btn_5_s').click()
            #time.sleep(3)
            ele_equals = self.driver.find_element_by_accessibility_id('equals').click()
            #time.sleep(3)
            result = self.driver.find_element_by_id('com.miui.calculator:id/result')
            print("subtraction done successfully")
            return result.text
        except Exception as e:
            print("something went wrong in calculator {}".format(e))

    def multipication(self,timeout=5):
        try:
            #clear = self.driver.find_element_by_accessibility_id('clear').click()
            clear = self.clear()
            #time.sleep(3)
            ele8 = self.driver.find_element_by_id('com.miui.calculator:id/btn_8_s').click()
            #time.sleep(3)
            ele_plus = self.driver.find_element_by_accessibility_id('multiply').click()
            #time.sleep(3)
            ele5 = self.driver.find_element_by_id('com.miui.calculator:id/btn_5_s').click()
            #time.sleep(3)
            ele_equals = self.driver.find_element_by_accessibility_id('equals').click()
            #time.sleep(3)
            result = self.driver.find_element_by_id('com.miui.calculator:id/result')
            print("multiplication done successfuly")
            return result.text
        except Exception as e:
            print("something went wrong in calculator {}".format(e))

    def division(self,timeout = 5):
        try:
            #clear = self.driver.find_element_by_accessibility_id('clear').click()
            clear = self.clear()
            #time.sleep(3)
            ele8 = self.driver.find_element_by_id('com.miui.calculator:id/btn_8_s').click()
            #time.sleep(3)
            ele_plus = self.driver.find_element_by_accessibility_id('divide').click()
            #time.sleep(3)
            ele5 = self.driver.find_element_by_id('com.miui.calculator:id/btn_5_s').click()
            #time.sleep(3)
            ele_equals = self.driver.find_element_by_accessibility_id('equals').click()
            #time.sleep(3)
            result = self.driver.find_element_by_id('com.miui.calculator:id/result')
            print("Division done successfully")
            return result.text
        except Exception as e:
            print("something went wrong in calculator {}".format(e))

if __name__ == '__main__':
    s = Connect()
    #s.connect()
    #s.pop_up_handle()
    print(s.addition())
    print(s.subtraction())
    print(s.multipication())
    print(s.division())







