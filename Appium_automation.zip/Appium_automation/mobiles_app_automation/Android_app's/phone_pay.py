import time
from appium import webdriver

class Connect:

    def __init__(self):
        self.driver = webdriver
        self.connect()

    def connect(self):
        try:
            capabilities = {'platformName': 'Android', 'platformVersion': '10',
                            'deviceName': 'chenna', 'deviceID': '8cc6f1da',
                            'appPackage':'com.phonepe.app',
                            'appActivity':'.v4.nativeapps.splash.Navigator_SplashActivity'}

            self.driver = webdriver.Remote('http://localhost:4723/wd/hub', capabilities)
            print("Connection successfully done")
            return self.driver

        except Exception as e:
            print("Error while connecting with appium {}".format(e))

    def add_phone_num(self):
        try:
            phone_num = self.driver.find_element_by_id('com.google.android.gms:id/credential_primary_label').click()
            print("Phone number added successfully")
            time.sleep(15)
        except Exception as e:
            print("Error with phone number {}".format(e))
    def pop_up_allow_sms(self):
        try:
            allow_sms = self.driver.find_element_by_id(
                'com.android.permissioncontroller:id/permission_allow_button').click()
            print("allow sms option clicked successfully")
            time.sleep(15)
        except Exception as e:
            print("Error on clicking the allow sms {}".format(e))
    def login_otp(self):
        try:
            login_otp = self.driver.find_element_by_id('com.phonepe.app:id/tv_navigate_option').click()
            print("login otp clicked successfully")
            time.sleep(20)
        except Exception as e:
            print("Error on clicking the login otp {}".format(e))
    def click_allow(self):
        try:
            contacts_allow = self.driver.find_element_by_id(
                'com.android.permissioncontroller:id/permission_allow_button')
            contacts_allow.click()
            print("contacts allow button clicked successfully")
            time.sleep(10)
            manage_calls_allow = self.driver.find_element_by_id(
                'com.android.permissioncontroller:id/permission_allow_button')
            manage_calls_allow.click()
            print("manage phone calls clicked successduly")
            time.sleep(10)
            device_location = self.driver.find_element_by_id(
                'com.android.permissioncontroller:id/permission_allow_foreground_only_button').click()
            print("device location clicked successfully")
            time.sleep(10)
        except Exception as e:
            print("Error clicking on allow button {}".format(e))

    def click_to_contact(self):
        try:
            to_contacts = self.driver.find_element_by_id('com.phonepe.app:id/tv_check_balance_title').click()
            print("successfully clicked To contacts")
            time.sleep(10)
        except Exception as e:
            print("Error on clicking the To contact {}".format(e))

    def click_search(self):
        try:
            search_contact = self.driver.find_element_by_id('com.phonepe.app:id/et_search_box').click()
            print("search contact clicked successfully")
            time.sleep(15)
        except Exception as e:
            print("Error on clicking on search  {}".format(e))
    def enter_num(self):
        try:
            enter_num = self.driver.find_element_by_id('com.phonepe.app:id/et_search_box').send_keys('9986727798')
            print("phone num entered successfully")
            time.sleep(10)
        except Exception as e:
            print("Error while entering the number {}".format(e))

    def select_contact(self):
        try:
            contact_click = self.driver.find_element_by_id('com.phonepe.app:id/tv_contact_name').click()
            print("contact clicked successfuuly")
            time.sleep(10)
        except Exception as e:
            print("Error while selecting the contact {}".format(e))

    def enter_amt(self):
        try:
            enter_amt = self.driver.find_element_by_id('com.phonepe.app:id/etInput').send_keys('1')
            print("amount entered successfully")
            time.sleep(10)
        except Exception as e:
            print("Error while entering the amount {}".format(e))

    def click_send_button(self):
        try:
            click_send = self.driver.find_element_by_id('com.phonepe.app:id/actionPay').click()
            print("send  clicked  successfully")
        except Exception as e:
            print("Error on clicking the send button {}".format(e))

if __name__ == "__main__":
    s = Connect()
    print(s.add_phone_num())
    print(s.pop_up_allow_sms())
    print(s.login_otp())
    print(s.click_allow())
    #print(s.click_to_contact())
    #print(s.click_search())
    #print(s.enter_num())
    #print(s.select_contact())
    #print(s.enter_amt())
    #print(s.click_send_button())
