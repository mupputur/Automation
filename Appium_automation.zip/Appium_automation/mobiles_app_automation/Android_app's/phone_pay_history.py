import time
from appium import webdriver

class Connect:

    def __init__(self):
        self.driver = webdriver
        self.connect()

    def connect(self):
        try:
            capabilities = {'platformName': 'Android', 'platformVersion': '10',
                            'deviceName': 'chenna', 'deviceID': '8cc6f1da',
                            'appPackage':'com.phonepe.app',
                            'appActivity':'.v4.nativeapps.splash.Navigator_SplashActivity'}

            self.driver = webdriver.Remote('http://localhost:4723/wd/hub', capabilities)
            print("Connection successfully done")
            time.sleep(10)
            return self.driver

        except Exception as e:
            print("Error while connecting with appium {}".format(e))

    def add_phone_num(self):
        try:
            self.phone_num = self.driver.find_element_by_id('com.google.android.gms:id/credential_primary_label').click()
            print("Phone number added successfully")
            time.sleep(15)
        except Exception as e:
            print("Error with phone number {}".format(e))
        return self.phone_num
    def pop_up_allow_sms(self):
        try:
            self.allow_sms = self.driver.find_element_by_id(
                'com.android.permissioncontroller:id/permission_allow_button').click()
            print("allow sms option clicked successfully")
            time.sleep(15)
        except Exception as e:
            print("Error on clicking the allow sms {}".format(e))
        return self.allow_sms
    def login_otp(self):
        try:
            self.login_otp = self.driver.find_element_by_id('com.phonepe.app:id/tv_navigate_option').click()
            print("login otp clicked successfully")
            time.sleep(20)
        except Exception as e:
            print("Error on clicking the login otp {}".format(e))
        return self.login_otp
    def click_allow(self):
        try:
            self.contacts_allow = self.driver.find_element_by_id(
                'com.android.permissioncontroller:id/permission_allow_button')
            self.contacts_allow.click()
            print("contacts allow button clicked successfully")
            time.sleep(10)
            self.manage_calls_allow = self.driver.find_element_by_id(
                'com.android.permissioncontroller:id/permission_allow_button')
            self.manage_calls_allow.click()
            print("manage phone calls clicked successfuly")
            time.sleep(10)
            self.device_location = self.driver.find_element_by_id(
                'com.android.permissioncontroller:id/permission_allow_foreground_only_button').click()
            print("device location clicked successfully")
            time.sleep(10)
        except Exception as e:
            print("Error clicking on allow button {}".format(e))
        return self.device_location
    
    def click_history(self):
        try:

            self.history = self.driver.find_element_by_id('com.phonepe.app:id/tab_transactions').click()
            print("History icon clicked successfuly")
            time.sleep(10)

            ele = self.driver.find_elements_by_class_name('android.widget.RelativeLayout')
            #print(type(ele))
            #print("Element {}".format(ele))

            for i in ele:
                print("i {}".format(i))
                paid_or_received = self.driver.find_element_by_id('com.phonepe.app:id/tv_transaction_name')
                print("paid_or_received {}".format(paid_or_received))
                if i == paid_or_received:
                    d = i.text
                    print("d {}".format(d))
            #print("paid_or_received {} ".format(paid_or_received))
        except Exception as e:
            print("Error on clicking the history icon {}".format(e))

    def get_data(self):
        try:
            Paid_to = []
            name = self.driver.find_element_by_id('com.phonepe.app:id/tv_transaction_payee_name')
            amt = self.driver.find_element_by_id('com.phonepe.app:id/tv_transaction_amount')
            paid_or_received = self.driver.find_element_by_id('com.phonepe.app:id/tv_transaction_name')
            if paid_or_received.text == 'Paid to':
                Paid_to.append(name.text)
                Paid_to.append(amt.text)
            return Paid_to

        except Exception as e:
            print("Error on getting data on history page {}".format(e))

    def all_data(self):
        try:
            data = self.driver.find_element_by_id('com.phonepe.app:id/rv_transaction_list')
            y = []
            for i in data:
                print(i)
                if i.text == 'Paid to':
                    name = self.driver.find_element_by_id('com.phonepe.app:id/tv_transaction_payee_name')
                    y.append(name.text)
                    amt = self.driver.find_element_by_id('com.phonepe.app:id/tv_transaction_amount')
                    y.append(amt.text)
                return y
        except Exception as e:
            print("something went wrong")


if __name__ == "__main__":
    s = Connect()
    print(s.add_phone_num())
    print(s.pop_up_allow_sms())
    print(s.login_otp())
    print(s.click_allow())
    print(s.click_history())
    #print(s.get_data())
    #print(s.all_data())