import time
from appium import webdriver
class Connect:
    def __init__(self):
        self.driver = webdriver

    def des_apps(self):
        try:
            capabilities = {'app': 'Microsoft.WindowsCalculator_8wekyb3d8bbwe!App',
                            'deviceName': 'chenna kesava',
                            'platformName': 'Windows'}

            self.driver = webdriver.Remote('http://localhost:4723/wd/hub', capabilities)
            print("Connection successfully done")
            self.driver.find_element_by_accessibility_id('num5Button').click()
            self.driver.find_element_by_accessibility_id('plusButton')
            self.driver.find_element_by_name('Eight').click()
            self.driver.find_element_by_class_name('Button')
            result = self.driver.find_element_by_accessibility_id('CalculatorResults')
            self.driver.close()
            return result.text

        except Exception as e:
            print("Error while connecting with appium {}".format(e))

if __name__ == "__main__":
    s = Connect()
    print(s.des_apps())